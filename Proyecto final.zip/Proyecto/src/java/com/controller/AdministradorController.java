/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entity.Administrador;
import com.entity.Cliente;
import com.entity.Cotizacion;
import com.entity.Producto;
import com.entity.Usuario;
import com.entity.Vendedor;
import com.services.AdministradorServices;
import com.services.ClienteServices;
import com.services.ProductoServices;
import com.services.VendedorServices;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Santiago
 */
@ManagedBean
@SessionScoped
public class AdministradorController implements Serializable {

    private Administrador administrador = new Administrador();

    private Cliente cliente = new Cliente();

    private Producto producto = new Producto();

    private Vendedor vendedor = new Vendedor();

    private Usuario usuario = new Usuario();

    private List<Cliente> clientes = new LinkedList();

    private List<Vendedor> vendedores = new LinkedList();

    private List<Producto> productos = new LinkedList();

    private List<Usuario> usuarios = new LinkedList();

    private List<Usuario> usuariosV = new LinkedList();

    private AdministradorServices adser = new AdministradorServices();

    private VendedorServices venser = new VendedorServices();

    private String paginaActual;

    @ManagedProperty("#{productoController}")
    private ProductoController porcon = new ProductoController();

    @ManagedProperty("#{cotizacionController}")
    private CotizacionController cotcon = new CotizacionController();
    
    

    public AdministradorController() {
    }

    /**
     *
     */
    public void registroVendedores() {

        paginaActual = "/Vistas/Administrador/RegistrarVendedor.xhtml";
    }

    /**
     *
     */
    public void verUsuarios() {

        paginaActual = "/Vistas/Administrador/Usuarios.xhtml";
    }

    public void gestionarCotizaciones() {

        paginaActual = "/Vistas/Vendedor/GestorCotizaciones.xhtml";
    }

    public void gestionarProductos() {

        paginaActual = "/Vistas/Vendedor/GestionProducto.xhtml";

    }

    public Administrador getAdministrador() {
        return administrador;
    }

    /**
     * @param administrador the administrador to set
     */
    public void setAdministrador(Administrador administrador) {
        this.administrador = administrador;
    }

    /**
     * @return the adser
     */
    public AdministradorServices getAdser() {
        return adser;
    }

    /**
     * @param adser the adser to set
     */
    public void setAdser(AdministradorServices adser) {
        this.adser = adser;
    }

    /**
     * @return the porcon
     */
    public ProductoController getPorcon() {
        return porcon;
    }

    /**
     * @param porcon the porcon to set
     */
    public void setPorcon(ProductoController porcon) {
        this.porcon = porcon;
    }

    /**
     * @return the cotcon
     */
    public CotizacionController getCotcon() {
        return cotcon;
    }

    /**
     * @param cotcon the cotcon to set
     */
    public void setCotcon(CotizacionController cotcon) {
        this.cotcon = cotcon;
    }

    /**
     * @return the vencon
     */
    /**
     * @return the paginaActual
     */
    public String getPaginaActual() {
        return paginaActual;
    }

    /**
     * @param paginaActual the paginaActual to set
     */
    public void setPaginaActual(String paginaActual) {
        this.paginaActual = paginaActual;
    }

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the vendedor
     */
    public Vendedor getVendedor() {
        return vendedor;
    }

    /**
     * @param vendedor the vendedor to set
     */
    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    /**
     * @return the productos
     */
    /**
     * @return the cliser
     */
    /**
     * @return the clientes
     */
    public List<Cliente> getClientes() {
        return clientes;
    }

    /**
     * @param clientes the clientes to set
     */
    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    /**
     * @return the productos
     */
    public List<Producto> getProductos() {
        return productos;
    }

    /**
     * @param productos the productos to set
     */
    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    /**
     * @return the producto
     */
    public Producto getProducto() {
        return producto;
    }

    /**
     * @param producto the producto to set
     */
    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    /**
     * @return the proser
     */
    

    /**
     * @return the vendedores
     */
    public List<Vendedor> getVendedores() {
        return vendedores;
    }

    /**
     * @param vendedores the vendedores to set
     */
    public void setVendedores(List<Vendedor> vendedores) {
        this.vendedores = vendedores;
    }

    /**
     * @return the venser
     */
    public VendedorServices getVenser() {
        return venser;
    }

    /**
     * @param venser the venser to set
     */
    public void setVenser(VendedorServices venser) {
        this.venser = venser;
    }

    /**
     * @return the usuario
     */
    public Usuario getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the usuarios
     */
    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    /**
     * @param usuarios the usuarios to set
     */
    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    /**
     * @return the usuariosV
     */
    public List<Usuario> getUsuariosV() {
        return usuariosV;
    }

    /**
     * @param usuariosV the usuariosV to set
     */
    public void setUsuariosV(List<Usuario> usuariosV) {
        this.usuariosV = usuariosV;
    }

    /**
     * @return the clicon
     */
   

    /**
     * @param clicon the clicon to set
     */
    

}
