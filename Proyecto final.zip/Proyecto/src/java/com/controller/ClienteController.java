/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entity.Cliente;
import com.services.ClienteServices;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author jcmm80
 */
@ManagedBean
@SessionScoped
public class ClienteController implements Serializable {

    private Cliente cliente = new Cliente();

    private ClienteServices cliser = new ClienteServices();

    private String paginaActual;

    private List<Cliente> clientes = new LinkedList();
    @ManagedProperty("#{productoController}")
    private ProductoController procon = new ProductoController();
    @ManagedProperty("#{cotizacionController}")
    private CotizacionController cotcon = new CotizacionController();
    
     @ManagedProperty(value = "#{administradorController}")
    private AdministradorController adcon = new AdministradorController();

    /**
     * Creates a new instance of ClienteController
     */
     
     String medioPago;

    public String getMedioPago() {
        return medioPago;
    }

    public void setMedioPago(String medioPago) {
        this.medioPago = medioPago;
    }
    public ClienteController() {
    }

    public void obtenerClientes(){
    
        setClientes(getCliser().consultarTodo(Cliente.class));
    }
    
    public void confirmarM(){
    
        
    }
    
    public void registrar() {
        cliente.setEstado("Activo");
        cliente.setTipo("Cliente");
        cliser.crear(cliente);
        cliente = new Cliente();
        FacesUtil.addInfoMessage("registro exitoso");
            

    }
    public boolean validarCliente() {
        boolean valida = true;
        if (cliente.getNombre().equals("")) {
            valida = false;
        }
        return valida;
    }

    public void verProductos() {
        paginaActual = "/Vistas/Cliente/VitrinaProductos.xhtml";
    }
    
    

    public void verCotizaciones() {
        paginaActual = "/Vistas/Cliente/MisCotizaciones.xhtml";
    }
    
    public void verPro() {
        paginaActual = "/Vistas/Administrador/MisCotizaciones.xhtml";
    
    }
   

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the paginaActual
     */
    public String getPaginaActual() {
        return paginaActual;
    }

    /**
     * @param paginaActual the paginaActual to set
     */
    public void setPaginaActual(String paginaActual) {
        this.paginaActual = paginaActual;
    }

    /**
     * @return the procon
     */
    public ProductoController getProcon() {
        return procon;
    }

    /**
     * @param procon the procon to set
     */
    public void setProcon(ProductoController procon) {
        this.procon = procon;
    }

    /**
     * @return the cotcon
     */
    public CotizacionController getCotcon() {
        return cotcon;
    }

    /**
     * @param cotcon the cotcon to set
     */
    public void setCotcon(CotizacionController cotcon) {
        this.cotcon = cotcon;
    }

    /**
     * @return the cliser
     */
    public ClienteServices getCliser() {
        return cliser;
    }

    /**
     * @param cliser the cliser to set
     */
    public void setCliser(ClienteServices cliser) {
        this.cliser = cliser;
    }

    /**
     * @return the vencon
     */
  
    /**
     * @return the adcon
     */
    public AdministradorController getAdcon() {
        return adcon;
    }

    /**
     * @param adcon the adcon to set
     */
    public void setAdcon(AdministradorController adcon) {
        this.adcon = adcon;
    }

    /**
     * @return the clientes
     */
    public List<Cliente> getClientes() {
        return clientes;
    }

    /**
     * @param clientes the clientes to set
     */
    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

}
