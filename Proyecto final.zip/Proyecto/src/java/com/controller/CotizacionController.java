/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entity.Cliente;
import com.entity.Cotizacion;
import com.entity.DetalleCotizacion;
import com.entity.Producto;
import com.services.CotizacionServices;
import com.services.DetalleCotizacionServices;
import java.io.Serializable;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author
 */
@ManagedBean
@SessionScoped
public class CotizacionController implements Serializable {

    private Cliente cliente = new Cliente();
    private List<DetalleCotizacion> detalles = new LinkedList();
    private Cotizacion cotizacion = new Cotizacion();

    private CotizacionServices cotser = new CotizacionServices();
    private DetalleCotizacionServices detser = new DetalleCotizacionServices();

    private List<Cotizacion> cotizaciones = new LinkedList();
    private List<Cliente> clientes = new LinkedList();
    private List<Cotizacion> cotizacionesS = new LinkedList();
    private List<Cotizacion> cotizacionesA = new LinkedList();
    private List<Cotizacion> cotizacionesC = new LinkedList();

    private double stotalp;
    private double subtotal;
    private double tpiva;
    private double stiva;

    /**
     * Creates a new instance of CotizacionController
     */
    public CotizacionController() {
    }

    public void obtenerCotizacionesSolicitadas() {
        cotizacionesS = new LinkedList();
        for (Cotizacion c : getCotizaciones()) {
            if (c.getEstado().equals("Solicitado")) {
                cotizacionesS.add(c);
            }
        }
    }

    public void obtenerCotizacionesAprobadas() {
        cotizacionesA = new LinkedList();
        for (Cotizacion c : getCotizaciones()) {
            if (c.getEstado().equals("Aprobado")) {
                cotizacionesA.add(c);
            }
        }
    }
    
    public void obtenerCotizacionesAprobadasc() {
        cotizacionesC = new LinkedList();
        for (Cotizacion c : getCotizaciones()) {
            if (c.getEstado().equals("Cancelado")) {
                cotizacionesC.add(c);
            }
        }
    }
     

   

    public void obtenerCotizacionesCliente() {
        detalles = new LinkedList();
        setCotizaciones(getCotser().cotizacionesCliente(cliente));
        obtenerCotizacionesSolicitadas();
        obtenerCotizacionesAprobadas();
        obtenerCotizacionesAprobadasc();
        
    }

    public void obtenerCotizaciones() {
        detalles = new LinkedList();
        setCotizaciones(getCotser().consultarTodo(Cotizacion.class));
        obtenerCotizacionesSolicitadas();
        obtenerCotizacionesAprobadas();
        obtenerCotizacionesAprobadasc();
    }

    public void obtenerdetalles(Cotizacion c) {
        detalles = getDetser().detallesCotizacion(c);
        cotizacion = c;
        obtenerValores(detalles);
    }

    public void resetearv() {
        stotalp = 0;
        subtotal = 0;
    }

    public void obtenerValores(List<DetalleCotizacion> dets) {
        resetearv();
        for (DetalleCotizacion dc : dets) {
            stotalp = stotalp + dc.subtotalP();
            subtotal = subtotal + dc.subtotal();
        }
        tpiva = (stotalp * 0.19) + stotalp;
        stiva = (subtotal * 0.19) + subtotal;
    }

    public void aprobar() {
        if (cotizacion.getId() != null) {
            cotizacion.setEstado("Aprobado");
            cotizacion = getCotser().modificar(cotizacion);
            obtenerCotizaciones();
        }
    }

    public void comprar() {
        if (cotizacion.getId() != null) {
            cotizacion.setEstado("Cancelado");
            cotizacion = getCotser().modificar(cotizacion);
            obtenerCotizaciones();
        }
    }

    public void quitar(DetalleCotizacion dc) {
        detalles.remove(dc);

    }

    public void agregarProducto(Producto p) {
        DetalleCotizacion dc = new DetalleCotizacion();
        dc.setProducto(p);
        if (!existeProducto(p)) {
            detalles.add(dc);
        } else {
            FacesUtil.addWarnMessage("El producto ya esta seleccionado");
        }
    }

    public boolean existeProducto(Producto p) {
        boolean exixte = false;
        for (DetalleCotizacion det : detalles) {
            if (det.getProducto().getId().equals(p.getId())) {
                exixte = true;
                break;
            }
        }
        return exixte;
    }

    public void almacenarCotizacion() {
        if (detalles.size() > 0) {
            cotizacion.setCliente(cliente);
            cotizacion.setEstado("Solicitado");
            cotizacion.setFecha(new Date());
            cotizacion = getCotser().modificar(cotizacion);
            for (DetalleCotizacion det : detalles) {
                det.setCotizacion(cotizacion);
                getDetser().modificar(det);
            }
            cotizacion = new Cotizacion();
            detalles = new LinkedList();
            obtenerCotizaciones();
            obtenerCotizacionesAprobadasc();
        } else {
            FacesUtil.addErrorMessage("No hay detalles de cotización");
        }
    }

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the detalles
     */
    public List<DetalleCotizacion> getDetalles() {
        return detalles;
    }

    /**
     * @param detalles the detalles to set
     */
    public void setDetalles(List<DetalleCotizacion> detalles) {
        this.detalles = detalles;
    }

    /**
     * @return the cotizacion
     */
    public Cotizacion getCotizacion() {
        return cotizacion;
    }

    /**
     * @param cotizacion the cotizacion to set
     */
    public void setCotizacion(Cotizacion cotizacion) {
        this.cotizacion = cotizacion;
    }

    /**
     * @return the cotizacionesS
     */
    public List<Cotizacion> getCotizacionesS() {
        return cotizacionesS;
    }

    /**
     * @param cotizacionesS the cotizacionesS to set
     */
    public void setCotizacionesS(List<Cotizacion> cotizacionesS) {
        this.cotizacionesS = cotizacionesS;
    }

    /**
     * @return the cotizacionesA
     */
    public List<Cotizacion> getCotizacionesA() {
        return cotizacionesA;
    }

    /**
     * @param cotizacionesA the cotizacionesA to set
     */
    public void setCotizacionesA(List<Cotizacion> cotizacionesA) {
        this.cotizacionesA = cotizacionesA;
    }

    /**
     * @return the stotalp
     */
    public double getStotalp() {
        return stotalp;
    }

    /**
     * @param stotalp the stotalp to set
     */
    public void setStotalp(double stotalp) {
        this.stotalp = stotalp;
    }

    /**
     * @return the subtotal
     */
    public double getSubtotal() {
        return subtotal;
    }

    /**
     * @param subtotal the subtotal to set
     */
    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    /**
     * @return the tpiva
     */
    public double getTpiva() {
        return tpiva;
    }

    /**
     * @param tpiva the tpiva to set
     */
    public void setTpiva(double tpiva) {
        this.tpiva = tpiva;
    }

    /**
     * @return the stiva
     */
    public double getStiva() {
        return stiva;
    }

    /**
     * @param stiva the stiva to set
     */
    public void setStiva(double stiva) {
        this.stiva = stiva;
    }

    /**
     * @return the cotser
     */
    public CotizacionServices getCotser() {
        return cotser;
    }

    /**
     * @param cotser the cotser to set
     */
    public void setCotser(CotizacionServices cotser) {
        this.cotser = cotser;
    }

    /**
     * @return the detser
     */
    public DetalleCotizacionServices getDetser() {
        return detser;
    }

    /**
     * @param detser the detser to set
     */
    public void setDetser(DetalleCotizacionServices detser) {
        this.detser = detser;
    }

    /**
     * @return the cotizaciones
     */
    public List<Cotizacion> getCotizaciones() {
        return cotizaciones;
    }

    /**
     * @param cotizaciones the cotizaciones to set
     */
    public void setCotizaciones(List<Cotizacion> cotizaciones) {
        this.cotizaciones = cotizaciones;
    }

    /**
     * @return the cotizacionesC
     */
    public List<Cotizacion> getCotizacionesC() {
        return cotizacionesC;
    }

    /**
     * @param cotizacionesC the cotizacionesC to set
     */
    public void setCotizacionesC(List<Cotizacion> cotizacionesC) {
        this.cotizacionesC = cotizacionesC;
    }

    /**
     * @return the clientes
     */
    public List<Cliente> getClientes() {
        return clientes;
    }

    /**
     * @param clientes the clientes to set
     */
    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }

    

}
