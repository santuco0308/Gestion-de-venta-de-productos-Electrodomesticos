/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entity.DetalleCotizacion;
import com.entity.Producto;
import static com.entity.Producto_.cantidad;
import com.entity.Vendedor;
import com.services.ProductoServices;
import com.services.VendedorServices;
import com.utilidades.ImageUtils;
import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import org.primefaces.model.file.UploadedFile;

/**
 *
 * @author jcmm80
 */
@ManagedBean
@SessionScoped
public class ProductoController implements Serializable{

    //entidades de negocio
    private Producto producto = new Producto();
    
    private UploadedFile filep;

    //servicios
    private ProductoServices proser = new ProductoServices();

    //colecciones
    private List<Producto> productos = new LinkedList();
     
     private List<Producto> BuscarProducto;

     private List<Vendedor> vendedores = new LinkedList();
     
     private VendedorServices venser = new VendedorServices();

    public VendedorServices getVenser() {
        return venser;
    }

    public void setVenser(VendedorServices venser) {
        this.venser = venser;
    }

    public List<Vendedor> getVendedores() {
        return vendedores;
    }

    public void setVendedores(List<Vendedor> vendedores) {
        this.vendedores = vendedores;
    }

    /**
     * Creates a new instance of ProductoController
     */
    public ProductoController() {

    }
    
    public void upload() {
        if (filep != null) {
            try {
                ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
                String path = servletContext.getRealPath("/menu.png");
                path=path.replace("menu.png", "Imagenes\\Productos\\");
                System.out.println(path);
                ImageUtils.copyFile(producto.getId()+".png", filep.getInputStream(), path);
                obtenerProductos();
            } catch (IOException ex) {                
                Logger.getLogger(ProductoController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
            FacesUtil.addErrorMessage("no hay archivo seleccionado");
        }
    }
    
    public void consultar(Producto p) {
        producto = p;
    }
    
   

    public void deshabilitar(Producto p) {
        p.setEstado("Inactivo");
        p = getProser().modificar(p);
        obtenerProductos();
    }

    public void eliminar(Producto p){
    
       productos.remove(p);
    }
    public boolean validarProducto() {
        boolean valida = true;
        if (producto.getNombre().equals("")) {
            valida = false;
        }
        return valida;
    }

    public void nuevoProducto(){
        producto = new Producto();
    }
    
    public void registrar() {
        producto.setEstado("Activo");
        if (validarProducto()) {
            getProser().crear(producto);
            producto = new Producto();
            obtenerProductos();
        }
    }

    public void obtenerProductos() {
        
        productos = getProser().consultarTodo(Producto.class);
    }
    
    
    public void obtenerVendedores() {
        
        vendedores = getVenser().consultarTodo(Vendedor.class);
    }

    /**
     * @return the producto
     */
    public Producto getProducto() {
        return producto;
    }

    /**
     * @param producto the producto to set
     */
    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    /**
     * @return the productos
     */
    public List<Producto> getProductos() {
        return productos;
    }

    /**
     * @param productos the productos to set
     */
    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    /**
     * @return the filep
     */
    public UploadedFile getFilep() {
        return filep;
    }

    /**
     * @param filep the filep to set
     */
    public void setFilep(UploadedFile filep) {
        this.filep = filep;
    }

    /**
     * @return the proser
     */
    public ProductoServices getProser() {
        return proser;
    }

    /**
     * @param proser the proser to set
     */
    public void setProser(ProductoServices proser) {
        this.proser = proser;
    }

    /**
     * @return the BuscarProducto
     */
    public List<Producto> getBuscarProducto() {
        return BuscarProducto;
    }

    /**
     * @param BuscarProducto the BuscarProducto to set
     */
    public void setBuscarProducto(List<Producto> BuscarProducto) {
        this.BuscarProducto = BuscarProducto;
    }

}
