/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entity.Administrador;
import com.entity.Cliente;
import com.entity.Usuario;
import com.entity.Vendedor;
import com.services.AdministradorServices;
import com.services.ClienteServices;
import com.services.UsuarioServices;
import com.services.VendedorServices;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Santiago
 */
@ManagedBean
@SessionScoped
public class UsuarioController implements Serializable {

    private Usuario usuario = new Usuario();

    private Vendedor vendedor = new Vendedor();

    private Cliente cliente = new Cliente();

    private Administrador administrador = new Administrador();

    private String PaginaActual = "";
    private boolean mostpanel = false;

    private UsuarioServices ususer = new UsuarioServices();
    private ClienteServices cliser = new ClienteServices();
    private VendedorServices venser = new VendedorServices();
    private AdministradorServices adser = new AdministradorServices();

    @ManagedProperty(value = "#{vendedorController}")
    private VendedorController vencon = new VendedorController();

    @ManagedProperty(value = "#{clienteController}")
    private ClienteController clicon = new ClienteController();

    @ManagedProperty(value = "#{administradorController}")
    private AdministradorController adcon = new AdministradorController();

    public UsuarioController() {

    }

    public void cerrar() {
        usuario = new Usuario();;
        vendedor = null;
        cliente = null;
        setMostpanel(false);
    }

    public void iniciar() {

        usuario = ususer.ingresar(usuario.getLogin(), usuario.getPassword());

        if (usuario.getId() != null) {
            setMostpanel(true);
            if (usuario.getTipo().equals("Cliente")) {
                setCliente(cliser.consultar(Cliente.class, usuario.getId()));
                clicon.getProcon().obtenerProductos();
                clicon.getCotcon().setCliente(cliente);
                clicon.getCotcon().obtenerCotizacionesCliente();
                clicon.getCotcon().obtenerCotizacionesSolicitadas();
                
                
                PaginaActual = "GUICliente.xhtml";
            }
            if (usuario.getTipo().equals("Vendedor")) {
                setVendedor(venser.consultar(Vendedor.class, usuario.getId()));
                vencon.getPorcon().obtenerProductos();
                vencon.getCotcon().obtenerCotizaciones();
                
                PaginaActual = "GUIVendedor.xhtml";

            }
            if (usuario.getTipo().equals("Administrador")) {
                setAdministrador(adser.consultar(Administrador.class, usuario.getId()));
                adcon.getPorcon().obtenerProductos();
                adcon.getCotcon().obtenerCotizacionesAprobadas();
                adcon.getCotcon().obtenerCotizaciones();
                
                PaginaActual = "GUIAdministrador.xhtml";
            }
        } else {
            setMostpanel(false);
            FacesUtil.addErrorMessage("El usuario no existe");
        }

    }

    public void registrarse() {
        setMostpanel(true);
        PaginaActual = "Vistas/Cliente/RegistoCliente.xhtml";
    }

    public void pagarProducto() {
        setMostpanel(true);
        PaginaActual = "Vistas/Cliente/PagoProducto.xhtml";
    }

    /**
     * @return the usuario
     */
    public Usuario getUsuario() {
        return usuario;
    }

    public AdministradorController getAdcon() {
        return adcon;
    }

    public void setAdcon(AdministradorController adcon) {
        this.adcon = adcon;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the mostrarPanelInicial
     */
    /**
     * @return the ususer
     */
    /**
     * @return the PaginaActual
     */
    public String getPaginaActual() {
        return PaginaActual;
    }

    /**
     * @param PaginaActual the PaginaActual to set
     */
    public void setPaginaActual(String PaginaActual) {
        this.PaginaActual = PaginaActual;
    }

    /**
     * @return the vendedor
     */
    public Vendedor getVendedor() {
        return vendedor;
    }

    /**
     * @param vendedor the vendedor to set
     */
    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    /**
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the ususer
     */
    public UsuarioServices getUsuser() {
        return ususer;
    }

    /**
     * @param ususer the ususer to set
     */
    public void setUsuser(UsuarioServices ususer) {
        this.ususer = ususer;
    }

    /**
     * @return the cliser
     */
    public ClienteServices getCliser() {
        return cliser;
    }

    /**
     * @param cliser the cliser to set
     */
    public void setCliser(ClienteServices cliser) {
        this.cliser = cliser;
    }

    /**
     * @return the venser
     */
    public VendedorServices getVenser() {
        return venser;
    }

    /**
     * @param venser the venser to set
     */
    public void setVenser(VendedorServices venser) {
        this.venser = venser;
    }

    /**
     * @return the mostPis
     */
    /**
     * @return the vencon
     */
    public VendedorController getVencon() {
        return vencon;
    }

    /**
     * @param vencon the vencon to set
     */
    public void setVencon(VendedorController vencon) {
        this.vencon = vencon;
    }

    /**
     * @return the clicon
     */
    public ClienteController getClicon() {
        return clicon;
    }

    /**
     * @param clicon the clicon to set
     */
    public void setClicon(ClienteController clicon) {
        this.clicon = clicon;
    }

    /**
     * @return the mostpanel
     */
    public boolean isMostpanel() {
        return mostpanel;
    }

    /**
     * @param mostpanel the mostpanel to set
     */
    public void setMostpanel(boolean mostpanel) {
        this.mostpanel = mostpanel;
    }

    /**
     * @return the administrador
     */
    public Administrador getAdministrador() {
        return administrador;
    }

    /**
     * @param administrador the administrador to set
     */
    public void setAdministrador(Administrador administrador) {
        this.administrador = administrador;
    }

    /**
     * @return the adser
     */
    public AdministradorServices getAdser() {
        return adser;
    }

    /**
     * @param adser the adser to set
     */
    public void setAdser(AdministradorServices adser) {
        this.adser = adser;
    }

    private void obtenerVendedores() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
