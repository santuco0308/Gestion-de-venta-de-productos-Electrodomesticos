/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entity.Producto;
import com.entity.Vendedor;
import com.services.VendedorServices;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Santiago
 */
@ManagedBean
@SessionScoped
public class VendedorController implements Serializable {

    
    
    
    @ManagedProperty("#{productoController}")
    private ProductoController porcon =new ProductoController();
    
    @ManagedProperty("#{cotizacionController}")
    private CotizacionController cotcon=new CotizacionController();
    
    private Vendedor vendedor = new Vendedor();
    
    private VendedorServices venser = new VendedorServices();
   
    private List<Vendedor> vendedores = new LinkedList();
    
    private String PaginaActual="";
    
    public VendedorController() {
    }

    
    public void obtenerVendedores() {
        
        vendedores = getVenser().consultarTodo(Vendedor.class);
    }
  public void registrar() {

        venser.crear(vendedor);
        vendedor.setEstado("Activo");
        vendedor = new Vendedor();
        vendedor.setTipo("Vendedor");

    }
    
    public void gestionarProductos(){
    
    PaginaActual="/Vistas/Vendedor/GestionProducto.xhtml";
    
    }
    
    public void gestionarCotizaciones(){
       
        PaginaActual="/Vistas/Vendedor/GestorCotizaciones.xhtml";
    }
    
    public void registraVendedor(){
    
         PaginaActual="/Vistas/Administrador/RegistrarVendedor.xhtml";
    }
    /**
     * @return the PaginaActual
     */
    public String getPaginaActual() {
        return PaginaActual;
    }

    /**
     * @param PaginaActual the PaginaActual to set
     */
    public void setPaginaActual(String PaginaActual) {
        this.PaginaActual = PaginaActual;
    }

    /**
     * @return the porcon
     */
    public ProductoController getPorcon() {
        return porcon;
    }

    /**
     * @param porcon the porcon to set
     */
    public void setPorcon(ProductoController porcon) {
        this.porcon = porcon;
    }

    /**
     * @return the cotcon
     */
    public CotizacionController getCotcon() {
        return cotcon;
    }

    /**
     * @param cotcon the cotcon to set
     */
    public void setCotcon(CotizacionController cotcon) {
        this.cotcon = cotcon;
    }

    /**
     * @return the adcon
     */
   

    /**
     * @return the vendedor
     */
    public Vendedor getVendedor() {
        return vendedor;
    }

    /**
     * @param vendedor the vendedor to set
     */
    public void setVendedor(Vendedor vendedor) {
        this.vendedor = vendedor;
    }

    /**
     * @return the venser
     */
    public VendedorServices getVenser() {
        return venser;
    }

    /**
     * @param venser the venser to set
     */
    public void setVenser(VendedorServices venser) {
        this.venser = venser;
    }

    /**
     * @return the vendedores
     */
    public List<Vendedor> getVendedores() {
        return vendedores;
    }

    /**
     * @param vendedores the vendedores to set
     */
    public void setVendedores(List<Vendedor> vendedores) {
        this.vendedores = vendedores;
    }

    /**
     * @return the contcon
     */
   
    
}
