/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;

/**
 *
 * @author Santiago
 */
@Entity
@PrimaryKeyJoinColumn(name = "id")
public class Vendedor extends Usuario implements Serializable {

   private String nombre;
    private String apellido;
    private String identificacion;
    private String Compañia;
    private String cargo;
    @OneToMany(mappedBy = "vendedor")
    private List<Cotizacion> cotizacions;

    public Vendedor() {
    }

    public Vendedor(String nombre, String apellido, String identificacion, String Compañia, String cargo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.identificacion = identificacion;
        this.Compañia = Compañia;
        this.cargo = cargo;
        
    }
    
    

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the apellido
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * @param apellido the apellido to set
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * @return the identificacion
     */
    public String getIdentificacion() {
        return identificacion;
    }

    /**
     * @param identificacion the identificacion to set
     */
    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    /**
     * @return the Compañia
     */
    public String getCompañia() {
        return Compañia;
    }

    /**
     * @param Compañia the Compañia to set
     */
    public void setCompañia(String Compañia) {
        this.Compañia = Compañia;
    }

    /**
     * @return the cargo
     */
    public String getCargo() {
        return cargo;
    }

    /**
     * @param cargo the cargo to set
     */
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    /**
     * @return the cotizacions
     */
    public List<Cotizacion> getCotizacions() {
        return cotizacions;
    }

    /**
     * @param cotizacions the cotizacions to set
     */
    public void setCotizacions(List<Cotizacion> cotizacions) {
        this.cotizacions = cotizacions;
    }

    /**
     * @return the cotizacion
     */
   
    

}

