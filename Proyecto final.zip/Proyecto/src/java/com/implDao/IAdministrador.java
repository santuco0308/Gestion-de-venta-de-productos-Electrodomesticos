package com.implDao;





import com.dao.IDao;
import com.entity.Administrador;
import com.entity.Cliente;

/**
 *
 * @author Jcmm
 */
public interface IAdministrador extends IDao<Administrador, Long>{
    
}
