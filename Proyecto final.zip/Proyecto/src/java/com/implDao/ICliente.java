package com.implDao;





import com.dao.IDao;
import com.entity.Cliente;

/**
 *
 * @author Jcmm
 */
public interface ICliente extends IDao<Cliente, Long>{
    
}
