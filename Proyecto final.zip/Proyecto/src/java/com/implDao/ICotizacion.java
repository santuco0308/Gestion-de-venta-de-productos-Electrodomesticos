package com.implDao;





import com.dao.IDao;
import com.entity.Cotizacion;

/**
 *
 * @author Jcmm
 */
public interface ICotizacion extends IDao<Cotizacion, Long>{
    
}
