package com.implDao;





import com.dao.IDao;
import com.entity.DetalleCotizacion;

/**
 *
 * @author Jcmm
 */
public interface IDetalleCotizacion extends IDao<DetalleCotizacion, Long>{
    
}
