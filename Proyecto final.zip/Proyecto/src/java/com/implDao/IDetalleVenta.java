package com.implDao;





import com.dao.IDao;
import com.entity.DetalleVenta;

/**
 *
 * @author Jcmm
 */
public interface IDetalleVenta extends IDao<DetalleVenta, Long>{
    
}
