package com.implDao;





import com.dao.IDao;
import com.entity.Cliente;
import com.entity.Producto;

/**
 *
 * @author Jcmm
 */
public interface IProducto extends IDao<Producto, Long>{
    
}
