package com.implDao;





import com.dao.IDao;
import com.entity.Promociones;

/**
 *
 * @author Jcmm
 */
public interface IPromociones extends IDao<Promociones, Long>{
    
}
