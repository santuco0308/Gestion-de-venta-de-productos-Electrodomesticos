package com.implDao;





import com.dao.IDao;
import com.entity.Usuario;

/**
 *
 * @author Jcmm
 */
public interface IUsuario extends IDao<Usuario, Long>{
    
}
