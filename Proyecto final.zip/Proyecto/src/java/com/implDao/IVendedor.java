package com.implDao;





import com.dao.IDao;
import com.entity.Vendedor;

/**
 *
 * @author Jcmm
 */
public interface IVendedor extends IDao<Vendedor, Long>{
    
}
