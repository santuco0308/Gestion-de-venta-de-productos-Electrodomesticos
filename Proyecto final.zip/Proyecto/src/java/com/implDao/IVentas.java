package com.implDao;





import com.dao.IDao;
import com.entity.Venta;

/**
 *
 * @author Jcmm
 */
public interface IVentas extends IDao<Venta, Long>{
    
}
