/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.services;

import com.dao.ImplDao;
import com.entity.Administrador;
import com.implDao.IAdministrador;
import java.io.Serializable;

/**
 *
 * @author Jcmm
 */

public class AdministradorServices extends ImplDao<Administrador, Long> implements IAdministrador, Serializable {

  
    
}
