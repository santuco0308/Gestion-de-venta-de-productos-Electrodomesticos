/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.services;

import com.dao.ImplDao;
import static com.dao.ImplDao.getEntityManagger;
import com.entity.Cliente;
import com.entity.Cotizacion;
import com.implDao.ICotizacion;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author Jcmm
 */

public class CotizacionServices extends ImplDao<Cotizacion, Long> implements ICotizacion, Serializable {

  public List<Cotizacion> cotizacionesSolicitadas(){
        List<Cotizacion> cotizaciones=new LinkedList();
        EntityManager em =getEntityManagger();
        //System.out.println(l+" y contraceña: "+c);
        em.getTransaction().begin();        
        String q="select c from Cotizacion c where c.estado=?1";        
        System.out.println(" Consulta: "+q);
        Query qu=em.createQuery(q)
                .setParameter(1,"Solicitado");
        cotizaciones=qu.getResultList();
        em.close();   
        return cotizaciones;   
    }
     
    public List<Cotizacion> cotizacionesCliente(Cliente c){
        List<Cotizacion> cotizaciones=new LinkedList();
        EntityManager em =getEntityManagger();
        //System.out.println(l+" y contraceña: "+c);
        em.getTransaction().begin();        
        String q="select c from Cotizacion c where c.cliente.id=?1";        
        System.out.println(" Consulta: "+q);
        Query qu=em.createQuery(q)
                .setParameter(1,c.getId());
        cotizaciones=qu.getResultList();
        em.close();   
        return cotizaciones;   
    }
    
}
