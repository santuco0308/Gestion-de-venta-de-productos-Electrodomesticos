/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.services;

import com.dao.ImplDao;
import com.entity.Producto;
import com.implDao.IProducto;
import java.io.Serializable;

/**
 *
 * @author Jcmm
 */

public class ProductoServices extends ImplDao<Producto, Long> implements IProducto, Serializable {

  
    
}
