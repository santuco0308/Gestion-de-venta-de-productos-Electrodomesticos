/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.services;

import com.dao.ImplDao;
import com.entity.Vendedor;
import com.implDao.IVendedor;
import java.io.Serializable;

/**
 *
 * @author Jcmm
 */

public class VendedorServices extends ImplDao<Vendedor, Long> implements IVendedor, Serializable {

  
    
}
